from tkinter import *
import tkinter as tk
from tkinter import filedialog, ttk

import skimage
from PIL import Image, ImageTk
import os # os module in Python provides functions for interacting with the operating system
import numpy as np
from numpy import asarray
import cv2 # Library of programming functions mainly aimed at real-time computer vision
from numpy import expand_dims
from tensorflow import keras

root = tk.Tk()
root.title("Brain tumor segmentation 🧠")
root.resizable(False, False)
model = []
images = []

def importModel():
    for widget in frame.winfo_children():
        widget.destroy()

    filename = filedialog.askopenfilename(initialdir="/", title="Select model",
                                          filetypes=(("models", "*.h5"), ("all files", "*.*")))
    model.clear()
    model.append(filename)

    if model != '':
        label_mod = tk.Label(frame_model, text='Loaded model is: ' + model[0], bg="gray")
        label_mod.pack()

def importImage():
    for widget in frame.winfo_children():
        widget.destroy()

    filename = filedialog.askopenfilename(initialdir=os.getcwd(), title="Select image",
                                          filetypes=(("Image", "*.png"), ("Image", "*.jpg"), ("all files", "*.*")))
    img = Image.open(filename)

    numpydata = asarray(img)
    images.clear()
    images.append(numpydata)
    img = ImageTk.PhotoImage(img)
    label_import = tk.Label(frame)
    label_import.configure(image=img, borderwidth=0)
    label_import.image = img
    label_import.pack()

def processImage():
    myModel = keras.models.load_model(model[0])
    imagine_test = images[0]

    width = 128
    height = 128
    dim = (width, height)
    resized_image = cv2.resize(imagine_test, dim, interpolation=cv2.INTER_LINEAR)

    # Reshape to comply with CNN's processing format
    resized_image = expand_dims(resized_image, axis=2)
    resized_image = resized_image.reshape((1,) + resized_image.shape)

    # Prediction processing
    prediction = myModel.predict([resized_image])

    category = ''
    if prediction[0][0] > 1.e-2:
        category = 'TUMOR'
        segmentButton['state'] = 'normal'
    else:
        category = 'NON TUMOR'
        segmentButton['state'] = 'disabled'

    label_prediction = tk.Label(frame, text='Image is from category: ' + category, bg="gray")
    label_prediction.pack()

def segmentImage():
    for widget in frame_2.winfo_children():
        widget.destroy()

    myModel = keras.models.load_model(model[0])

    featureMapsList = []

    layer_outputs = [layer.output for layer in myModel.layers[:]]
    activation_model = keras.Model(inputs=myModel.input, outputs=layer_outputs)

    imagine_test = images[0]

    width = 128
    height = 128
    dim = (width, height)
    resized_image = cv2.resize(imagine_test, dim, interpolation=cv2.INTER_LINEAR)

    resized_image = expand_dims(resized_image, axis=2)
    resized_image = resized_image.reshape((1,) + resized_image.shape)

    activations = activation_model.predict(resized_image)
    fifth_conv_layer = activations[10]

    for j in range(len(fifth_conv_layer[0])):
        featureMapsList.append(fifth_conv_layer[0, :, :, j])
    featureMapsList = np.array(featureMapsList)

    # Gradient
    grad_arrays = []
    for i in range(len(featureMapsList)):
        img = featureMapsList[i]

        sobelX = cv2.Sobel(img, cv2.CV_32F, 1, 0)
        sobelY = cv2.Sobel(img, cv2.CV_32F, 0, 1)
        sobelX = np.uint8(np.absolute(sobelX))
        sobelY = np.uint8(np.absolute(sobelY))

        sobelCombined = cv2.bitwise_or(sobelX, sobelY)

        grad_arrays.append(sobelCombined)
    grad_arrays = np.array(grad_arrays)

    # Compute average and global max values for gradients
    average_values = []
    max_values = []
    for i in range(len(grad_arrays)):
        average_values.append(np.mean(grad_arrays[i]))
        max_values.append(np.max(grad_arrays[i]))

    average_values = np.array(average_values)
    max_values = np.array(max_values)

    modifiedFeatureMapsList = np.copy(featureMapsList)
    # Multiply feature maps with average and global max values
    for i in range(len(featureMapsList)):
        for x in range(32):
            for y in range(32):
                modifiedFeatureMapsList[i][x][y] *= average_values[i]
                modifiedFeatureMapsList[i][x][y] *= max_values[i]

    arr2d_modifiedFeatureMapsList = np.reshape(modifiedFeatureMapsList,
                                               (int(len(modifiedFeatureMapsList) / 32), 32, 32, 32))

    meanImages = []
    for i in range(len(arr2d_modifiedFeatureMapsList)):
        processingImage = np.zeros((32, 32))
        processingImage = np.float32(processingImage)
        for j in range(32):
            processingImage = cv2.add(processingImage, arr2d_modifiedFeatureMapsList[i][j])
        meanImage = processingImage / 32
        meanImages.append(meanImage)

    finalNormalizedImages = [
        (cv2.normalize(meanImages[i], None, alpha=0, beta=255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32F)) for i in
        range(len(meanImages))]
    for elem in finalNormalizedImages:
        for i in range(32):
            for j in range(32):
                if elem[i][j] < 0:
                    elem[i][j] = 0

    # Reversing the intensity values so that the highest intensities represent the segmented tumor
    invertedValuesArray = []
    for element in finalNormalizedImages:
        mask = np.full(element.shape, 255)
        mod_img = mask - element
        mod_img = mod_img.astype(np.uint8)
        invertedValuesArray.append(mod_img)

        # Resize opened images
    width_dim = 152
    height_dim = 192
    dimension = (width_dim, height_dim)
    resized_segmented = [(cv2.resize(invertedValuesArray[i], dimension, interpolation=cv2.INTER_LINEAR)) for i in
                             range(len(invertedValuesArray))]

    # I apply a threshold function to keep only the pixels that represent the tumor
    tresholdResults = []
    for i in range(len(invertedValuesArray)):
        ret, image_result = cv2.threshold(resized_segmented[i], float(np.max(resized_segmented[i])) * float(cmb.get()),
                                          np.max(resized_segmented[i]), cv2.THRESH_BINARY)
        tresholdResults.append(image_result)

    # Morphological operations are applied on the segmentations
    kernel = np.ones((3, 3), np.float32)
    openedImages = [(cv2.morphologyEx(tresholdResults[i], cv2.MORPH_OPEN, kernel)) for i in range(len(tresholdResults))]
    kernel2nd = np.ones((1, 1), np.float32)
    openedImages2nd = [(cv2.morphologyEx(openedImages[i], cv2.MORPH_OPEN, kernel2nd)) for i in range(len(openedImages))]

    blurredImages = [(cv2.medianBlur(openedImages2nd[i], 5)) for i in range(len(openedImages2nd))]


    # Resize original image
    invertedValuesArray = [(cv2.resize(invertedValuesArray[i], dimension, interpolation=cv2.INTER_LINEAR)) for i in
                           range(len(invertedValuesArray))]

    # Create a mask with 0 intensity pixels for all elements from resized_segmented array
    masks_null = [(np.where(blurredImages[i] == 0)) for i in range(len(blurredImages))]

    # Apply a color map
    mapped_colors = [(cv2.applyColorMap(invertedValuesArray[i], cv2.COLORMAP_RAINBOW)) for i in
                     range(len(invertedValuesArray))]

    mapped_colors = np.array(mapped_colors)

    for i in range(len(mapped_colors)):
        (mapped_colors[i])[masks_null[i]] = 0

    original_image = np.array(imagine_test)
    resized_original_image = cv2.resize(original_image, dimension, interpolation=cv2.INTER_LINEAR)
    converted_image = np.float32(resized_original_image)
    backtorgb = cv2.cvtColor(converted_image, cv2.COLOR_GRAY2RGB)
    backtorgb = np.uint8(backtorgb)

    dst = cv2.add(backtorgb, mapped_colors[0])
    dst = Image.fromarray(dst)

    result = ImageTk.PhotoImage(dst)

    label_res = tk.Label(frame_2)
    label_res.configure(image=result, borderwidth=0)
    label_res.image = result
    label_res.pack(pady=25, anchor="center")

# UI Components
# Create canvas
canvas = tk.Canvas(root, height=600, width=700, bg="#263D42")
canvas.pack()

# Import logo
frame_logo = tk.Frame(root, bg="black")
frame_logo.place(relwidth=0.7, relheight=0.2, relx=0.15, rely=0.015)
label = tk.Label(frame_logo, text='Brain Tumor Segmentation App', font=('Times New Roman',17,'bold'),
                 bg="#000000", fg="#FFFFFF")
label.pack()

brain_logo = (Image.open("Logo/BrainLogo.jpg"))
resized_image = brain_logo.resize((100, 100))
new_image = ImageTk.PhotoImage(resized_image)
label_brain = tk.Label(frame_logo, image=new_image, borderwidth=0)
label_brain.pack()

# Model frame
frame_model_name = tk.Frame(root, bg="black")
frame_model_name.place(relwidth=0.2, relheight=0.03, relx=0.4, rely=0.22)
label_model_name = tk.Label(frame_model_name, text='Model', font=('Times New Roman', 17, 'bold'),
                            bg="#000000", fg="#FFFFFF")
label_model_name.pack()

frame_model = tk.Frame(root, bg="black")
frame_model.place(relwidth=0.84, relheight=0.03, relx=0.08, rely=0.25)

# Frame image 1
frame = tk.Frame(root, bg="black")
frame.place(relwidth=0.35, relheight=0.35, relx=0.1, rely=0.4)

frame_name = tk.Frame(root, bg="black")
frame_name.place(relwidth=0.25, relheight=0.05, relx=0.15, rely=0.35)
label_name = tk.Label(frame_name, text='FLAIR image', font=('Times New Roman', 17, 'bold'),
                      bg="#000000", fg="#FFFFFF")
label_name.pack()

# Frame image 2
frame_2 = tk.Frame(root, bg="black")
frame_2.place(relwidth=0.35, relheight=0.35, relx=0.55, rely=0.4)

frame_2_name = tk.Frame(root, bg="black")
frame_2_name.place(relwidth=0.3, relheight=0.05, relx=0.575, rely=0.35)
label_2_name = tk.Label(frame_2_name, text='Segmented image', font=('Times New Roman', 17, 'bold'),
                        bg="#000000", fg="#FFFFFF")
label_2_name.pack()

# Frame threshold
frame_threshold = tk.Frame(root, bg="#263D42")
frame_threshold.place(relwidth=0.3, relheight=0.03, relx=0.35, rely=0.775)

label_thresh = tk.Label(frame_threshold, text='Threshold value: ', font=('Times New Roman', 11, 'bold'),
                        bg="#263D42", fg="#FFFFFF")
label_thresh.config(width=12)
label_thresh.pack(side=tk.LEFT, padx=2)

# Dropdown list for threshold values
values = [round(0.33 + i*0.01, 2) for i in range(55)]
cmb = ttk.Combobox(frame_threshold, value=values, width=12)
cmb.current(10)
cmb.pack(side=tk.LEFT)

# Buttons
# 1
openModel = tk.Button(root, text="Import model", font=('Times New Roman', 10, 'bold'),
                      width=10, padx=15, pady=5, fg="white", bg="#263D42", command=importModel)
openModel.pack(side=tk.LEFT, padx=26.5)
# 2
openImage = tk.Button(root, text="Import image", font=('Times New Roman', 10, 'bold'),
                      width=10, padx=15, pady=5, fg="white", bg="#263D42", command=importImage)
openImage.pack(side=tk.LEFT, padx=19)
# 3
processButton = tk.Button(root, text="Clasify image", font=('Times New Roman', 10, 'bold'),
                          width = 10, padx=15, pady=5, fg="white", bg="#263D42", command=processImage)
processButton.pack(side=tk.LEFT, padx=19)
# 4
segmentButton = tk.Button(root, text="Segment image", font=('Times New Roman', 10, 'bold'),
                          width=10, padx=15, pady=5, fg="white", bg="#263D42", command=segmentImage)

segmentButton['state'] = 'disabled'

segmentButton.pack(side=tk.LEFT, padx=19)
# 5
closeApp = tk.Button(root, text="Exit", font=('Times New Roman', 10, 'bold'),
                     width=10, padx=10, pady=5, fg="white", bg="#263D42", command=lambda: exit())
closeApp.pack(side=tk.LEFT, padx=26.5)
# End UI Components
root.mainloop()